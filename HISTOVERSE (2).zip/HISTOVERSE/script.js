document.addEventListener('DOMContentLoaded', () => {
    const links = document.querySelectorAll('.subbab-link');
    const sections = document.querySelectorAll('.content-section');

    links.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            
            // Ambil ID target
            const targetId = link.getAttribute('data-target');

            // Sembunyikan semua section
            sections.forEach(section => {
                section.classList.remove('active');
            });

            // Tampilkan section yang dipilih
            const targetSection = document.getElementById(targetId);
            if (targetSection) {
                targetSection.classList.add('active');
                // Scroll ke atas konten
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }

            // Update status aktif pada link
            links.forEach(l => l.style.color = '#666');
            link.style.color = '#27ae60';
        });
    });
});